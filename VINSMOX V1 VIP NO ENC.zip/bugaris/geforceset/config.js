/*

 * Base By Rekenz
 * Jangan hapus credit ya anjing

 Contact Support:
 📞 Whatsapp : wa.me/628978575652
 ☎ Telegram : t.me/Rekenzx
 
*/

global.owner = [
  "601119496612", //ganti nomor owner
  "601119496612" //nomor owner kedua kalo ada
]

global.namaowner = 'Aris'
global.idsaluran = 'isi'
global.linkgc = '-'

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
